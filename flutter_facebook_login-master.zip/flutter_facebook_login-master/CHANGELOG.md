## 1.1.1

* Fix occasional hangs/freezes by introducing a slight artifical delay after getting the result from Facebook login.

## 1.1.0

* Dart 2 support! There should not be any breaking changes. Please do file issues if you have problems.

## 1.0.3

* Fixed potential crash and documented iOS logout issues when using the webOnly login behavior.

## 1.0.2

* Added new `isLoggedIn` and `currentAccessToken` getters which make it easier to log the user in automatically.

## 1.0.1

* Fixed the podspec definition for the iOS project.

## 1.0.0

* Initial release.
