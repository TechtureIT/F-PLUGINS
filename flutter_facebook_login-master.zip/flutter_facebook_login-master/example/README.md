# facebook_login_example

Demonstrates how to use the facebook_login plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
